# draw.io Desktop fork patch — v30.3.6-somr.1

This patch reproduces a personal fork's changes on top of vanilla
[jgraph/drawio-desktop](https://github.com/jgraph/drawio-desktop) **v30.3.6**,
without needing network access to the fork itself. It contains three changes:

1. **Path traversal fix** in `getPluginFile()` (`src/main/electron.js`).
   Previously the plugin filename coming from renderer/config was joined
   directly onto the plugins directory (`path.join(prefix, plugin)`). A
   plugin name containing `../` segments could escape that directory. The
   fix sanitizes the name first: `path.join(prefix, path.basename(plugin))`.

2. **`httpRequest` IPC action** (`src/main/electron.js`). Adds a new
   `httpRequest()` function (built on Node's `http`/`https` modules) and a
   matching `'httpRequest'` case in the `rendererReq` IPC handler, so a
   plugin can ask the Electron **main process** to make an outbound HTTP(S)
   request on its behalf — bypassing the renderer's Content-Security-Policy,
   which normally blocks this. This was added to support a plugin's
   "upload export to Confluence" feature.

   **Security note:** this handler does not restrict which host a plugin
   may target — any enabled plugin can direct the main process to reach
   arbitrary hosts, including internal network addresses or `localhost`.
   That's a broader trust surface than the renderer CSP alone provides.
   This is consistent with this project's existing plugin trust model
   (see `doc/PLUGIN_SECURITY.md` in the main repo: the signed app already
   trusts the plugins it runs), but it's worth being aware of before
   enabling third-party plugins with this build.

3. **Fork version suffix** (`sync.cjs`). Adds a `FORK_SUFFIX = '-somr.1'`
   constant that's appended to the version `sync.cjs` stamps into
   `package.json`, so builds from this patch show `30.3.6-somr.1` (e.g. in
   the About dialog) rather than the official `30.3.6` — making patched
   builds visibly distinguishable from official ones.

Files touched: `package.json`, `package-lock.json`, `sync.cjs`,
`src/main/electron.js`. The `drawio/` core-editor submodule is untouched —
this patch only changes the Electron shell.

## Contents of this zip

```
fork-changes.patch      unified git diff of the 4 files above, against vanilla v30.3.6
modified-files/         full post-patch copies of the same 4 files (fallback for manual apply)
README.md               this file
```

## Prerequisites

- git
- [Node.js](https://nodejs.org/) 22.12 or later, and npm

## 1. Get vanilla source at the matching base

This patch was generated against vanilla tag `v30.3.6`. Clone **recursively**
(the core editor is a git submodule) and check out that tag:

```
git clone --recursive https://github.com/jgraph/drawio-desktop.git
cd drawio-desktop
git checkout v30.3.6
git submodule update --init --recursive
```

## 2. Apply the patch

Copy `fork-changes.patch` into the repo root, then:

```
git apply fork-changes.patch
git diff --stat   # sanity check: should show exactly the 4 files listed above
```

**If `git apply` fails** (e.g. you're building from a newer vanilla tag and
the surrounding context has drifted), apply the change manually instead:

- Copy `modified-files/sync.cjs` and `modified-files/src/main/electron.js`
  over the matching paths in your checkout — these two files carry the
  actual logic changes.
- Don't copy `modified-files/package.json` or `package-lock.json` in this
  case — their version strings are specific to `30.3.6` and would be wrong
  for a different base. Instead just run `npm run sync` (step 3 below)
  after applying `sync.cjs`; its patched `FORK_SUFFIX` logic will stamp the
  version correctly from whatever `drawio/VERSION` your checkout has.

## 3. Install dependencies and sync the version

```
npm install
npm run sync -- disableUpdate
```

`sync` stamps the fork-suffixed version from `drawio/VERSION` into
`package.json`. `disableUpdate` stops the app auto-updating itself back to
an official (unpatched) release — recommended for any build you intend to
keep using, since auto-update would otherwise silently undo this patch.

## 4. Build

These call `electron-builder` directly (unlike the `npm run release-*`
scripts, which are for CI and try to publish to GitHub releases). Since this
isn't an officially signed build, use the unsigned/personal-build path.
Output lands in `dist/`.

### Linux

```
npx electron-builder --config electron-builder-linux-mac.json --linux AppImage deb --x64 --publish never
```

Linux builds are unsigned by default, no environment variable needed. Swap
in `rpm` (requires the `rpm` package installed) or `--arm64` as needed.

### Windows

In PowerShell:

```
$env:DRAWIO_UNSIGNED="true"
npx electron-builder --config electron-builder-win.json --publish never
```

or in cmd.exe:

```
set DRAWIO_UNSIGNED=true
npx electron-builder --config electron-builder-win.json --publish never
```

This produces the NSIS installer and MSI. `DRAWIO_UNSIGNED` only lasts for
the current terminal session — set it again in any new terminal, or it
fails with an error about a "Trusted Signing dlib". Windows SmartScreen
will warn when running the unsigned installer ("Windows protected your
PC") — choose **More info → Run anyway**. Building the Windows target is
most reliable done natively on Windows; cross-building from Linux via
Wine is possible with electron-builder but isn't the path documented or
tested here.

## More detail

The original repo's `doc/BUILDING_FOR_PERSONAL_USE.md` covers this same
ground in more depth — macOS builds, keeping a fork up to date, and building
unsigned installers via GitHub Actions instead of locally. Worth a read if
you're setting this up as an ongoing personal fork rather than a one-off
build.

## Verify it worked

- `git diff --stat` after applying should show 4 files changed.
- After building, install/run the app and check **Help → About**: the
  version should read `30.3.6-somr.1` (or `<your-version>-somr.1` if you
  applied this to a different base tag).
- The `httpRequest` IPC action and plugin path-traversal fix are only
  observable through a plugin that uses them — there's no UI-visible
  change beyond the version string.
